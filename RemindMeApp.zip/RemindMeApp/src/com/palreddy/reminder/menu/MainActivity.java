package com.palreddy.reminder.menu;

import com.palreddy.reminder.R;
import com.palreddy.reminder.R.layout;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;

public class MainActivity extends FragmentActivity {
	private FragmentTabHost mTabHost;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup(this, getSupportFragmentManager(),
				android.R.id.tabcontent);

		mTabHost.addTab(
				mTabHost.newTabSpec("shopping").setIndicator("Shopping", null),
				ShoppingFragment.class, null);
		mTabHost.addTab(
				mTabHost.newTabSpec("journey").setIndicator("Journey", null),
				JourneyFragment.class, null);
		mTabHost.addTab(mTabHost.newTabSpec("about")
				.setIndicator("About", null), AboutFragment.class, null);
	}
}
