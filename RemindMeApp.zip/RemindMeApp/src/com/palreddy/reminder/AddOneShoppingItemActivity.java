package com.palreddy.reminder;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.palreddy.reminder.helper.ServiceHandler;
import com.palreddy.reminder.helper.Validation;

public class AddOneShoppingItemActivity extends ActionBarActivity {

	private EditText editTextItems;
	private EditText editTextAdress;
	private EditText editTextestimatedAmt;
	private EditText editTexttitle;
	private EditText editdateShopping;
	private Button btnAdd;

	private String TextItems = "";
	private String TextAdress = "";
	private String TextestimatedAmt = "";
	private String Texttitle = "";
	private String dateShopping = "";

	private boolean isAdded = false;

	static Context ctx;

	private int serverOK = 0;
	private int signupOK = 0;
	private String userID = "";
	private ProgressDialog pDialog;
	private static final String TAG_SERVER_URL = "serverURL";
	private static String serverURL = "";
	private static String addshoppinglistURL = "/shopping/addshoppinglist";

	JSONArray loginRepJSON = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_one_shopping_item);
		getSupportActionBar().hide();

		serverURL = loadPrefs(TAG_SERVER_URL);
		ctx = getApplicationContext();

		// Edit Text
		editTextItems = (EditText) findViewById(R.id.editTextItems);
		editTextAdress = (EditText) findViewById(R.id.editTextAdress);
		editTextestimatedAmt = (EditText) findViewById(R.id.editTextestimatedAmt);
		editTexttitle = (EditText) findViewById(R.id.editTexttitle);
		editdateShopping = (EditText) findViewById(R.id.editdateShopping);

		// Add Button
		btnAdd = (Button) findViewById(R.id.btn_add);
		btnAdd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Validation.hasText(editTextItems);
				Validation.hasText(editTextAdress);
				Validation.hasText(editTextestimatedAmt);
				Validation.hasText(editTexttitle);
				Validation.hasText(editdateShopping);

				TextItems = editTextItems.getText().toString().trim();
				TextAdress = editTextAdress.getText().toString().trim();
				TextestimatedAmt = editTextestimatedAmt.getText().toString()
						.trim();
				Texttitle = editTexttitle.getText().toString().trim();
				dateShopping = editdateShopping.getText().toString().trim();

				if (editTextItems.length() != 0 && editTextAdress.length() != 0
						&& editTextestimatedAmt.length() != 0
						&& editTexttitle.length() != 0
						&& editdateShopping.length() != 0) {
					new addShop().execute();
				}
			}
		});
	}

	public String loadPrefs(String KEY) {

		SharedPreferences sh_Pref = getSharedPreferences("MyData",
				Context.MODE_PRIVATE);
		return sh_Pref.getString(KEY, null);
	}

	private class addShop extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Showing progress dialog
			pDialog = new ProgressDialog(AddOneShoppingItemActivity.this);
			pDialog.setMessage("Please wait...");
			pDialog.show();

		}

		@Override
		protected Void doInBackground(Void... arg0) {

			ServiceHandler sh = new ServiceHandler();
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();

			urlParameters
					.add(new BasicNameValuePair("idU", loadPrefs("userID")));
			urlParameters.add(new BasicNameValuePair("items", TextItems));
			urlParameters.add(new BasicNameValuePair("address", TextAdress));
			urlParameters.add(new BasicNameValuePair("estimatedAmt",
					TextestimatedAmt));
			urlParameters.add(new BasicNameValuePair("dateShopping",
					dateShopping));
			urlParameters.add(new BasicNameValuePair("title", Texttitle));

			String result = sh.makeServiceCall(serverURL + addshoppinglistURL,
					ServiceHandler.POST, urlParameters);

			Log.e("result >", "> " + result);
			if (result != null) {
				serverOK = 1;
				isAdded = Boolean.parseBoolean(result);
			} else {
				serverOK = 0;
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// Dismiss the progress dialog
			if (pDialog.isShowing())
				pDialog.cancel();
			/**
			 * Updating parsed JSON data into ListView
			 * */

			if (!isAdded) {
				if (serverOK == 1) {
					new AlertDialog.Builder(AddOneShoppingItemActivity.this)
							.setTitle("Message")
							.setMessage(
									"The Item has not been added. Try again please.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", null).show();
				} else {
					new AlertDialog.Builder(AddOneShoppingItemActivity.this)
							.setTitle("Message")
							.setMessage("Connection problem with the server.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", null).show();
				}

			} else {
				new AlertDialog.Builder(AddOneShoppingItemActivity.this)
						.setTitle("Message")
						.setMessage("Item added!")
						.setIcon(android.R.drawable.ic_dialog_info)
						.setNegativeButton("Ok",
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog,
											int which) {
										finish();

									}
								}).show();

			}

		}
	}
}
