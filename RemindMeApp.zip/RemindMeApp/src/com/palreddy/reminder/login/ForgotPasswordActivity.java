package com.palreddy.reminder.login;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.palreddy.reminder.R;
import com.palreddy.reminder.helper.ServiceHandler;
import com.palreddy.reminder.helper.Validation;

public class ForgotPasswordActivity extends ActionBarActivity implements
		OnItemSelectedListener, android.view.View.OnClickListener {

	private String[] questions = { "Question 1.", "Question 2.", "Question 3.",
			"Question 4.", "Question 5." };

	private EditText username;
	private EditText answer;
	private Spinner spinner;
	private Button submit;
	private TextView textViewSelect;

	private String selQuestion = "";

	private String usernameStr = "";

	static Context ctx;

	private int serverOK = 0;
	private int questionOK = 0;
	private ProgressDialog pDialog;
	private String userID;
	private String questionNumber;
	private String questionAnswer;
	private String serverUsername;
	private static final String TAG_SERVER_URL = "serverURL";
	private static String serverURL = "";
	private static String getQuestionInfoURL = "/login/getquestioninfo";

	JSONArray loginRepJSON = null;
	private static final String TAG_LOGIN_RESPONSE = "LoginResponse";
	private static final String TAG_ID = "id";
	private static final String TAG_QUESTION_NUMBER = "questionNumber";
	private static final String TAG_QUESTION_ANSWER = "questionAnswer";
	private static final String TAG_USERNAME = "username";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgot_password);
		getSupportActionBar().hide();

		serverURL = loadPrefs(TAG_SERVER_URL);

		// username
		username = (EditText) findViewById(R.id.editTextUsername);

		// spinner
		spinner = (Spinner) findViewById(R.id.spinner);
		spinner.setOnItemSelectedListener(this);

		// answer
		answer = (EditText) findViewById(R.id.editTextAnswer);

		// TextView
		textViewSelect = (TextView) findViewById(R.id.TextViewSelect);

		// submit button
		submit = (Button) findViewById(R.id.btn_confirm_submit);
		submit.setOnClickListener(this);
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		spinner.setSelection(position);
		selQuestion = (String) spinner.getSelectedItem();
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {

	}

	private void makeToast(String text) {
		Toast.makeText(ForgotPasswordActivity.this, text, Toast.LENGTH_SHORT)
				.show();
	}

	public String loadPrefs(String KEY) {

		SharedPreferences sh_Pref = getSharedPreferences("MyData",
				Context.MODE_PRIVATE);
		return sh_Pref.getString(KEY, null);
	}

	private class getQuestionInfo extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Showing progress dialog
			pDialog = new ProgressDialog(ForgotPasswordActivity.this);
			pDialog.setMessage("Please wait...");
			pDialog.show();

		}

		@Override
		protected Void doInBackground(Void... arg0) {

			ServiceHandler sh = new ServiceHandler();
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();

			urlParameters.add(new BasicNameValuePair("username", usernameStr));

			String result = sh.makeServiceCall(serverURL + getQuestionInfoURL,
					ServiceHandler.POST, urlParameters);

			Log.e("result >", "> " + result);
			if (result != null) {
				try {
					serverOK = 1;
					JSONObject jsonObj = new JSONObject(result);

					// Getting JSON Array node
					loginRepJSON = jsonObj.getJSONArray(TAG_LOGIN_RESPONSE);

					// looping through All Contacts

					JSONObject c = loginRepJSON.getJSONObject(0);

					serverUsername = c.getString(TAG_USERNAME);
					userID = c.getString(TAG_ID);
					if (usernameStr.equals(serverUsername)
							&& !userID.equals("-1") && !userID.equals("0")) {
						questionOK = 1;
						questionAnswer = c.getString(TAG_QUESTION_ANSWER);
						questionNumber = c.getString(TAG_QUESTION_NUMBER);
					} else {
						questionOK = 0;
					}

				} catch (JSONException e) {
					e.printStackTrace();
				}
			} else {
				serverOK = 0;
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			// Dismiss the progress dialog
			if (pDialog.isShowing())
				pDialog.cancel();
			/**
			 * Updating parsed JSON data into ListView
			 * */

			if (questionOK == 1) {
				submit.setText("Submit");
				answer.setVisibility(android.view.View.VISIBLE);
				textViewSelect.setVisibility(android.view.View.VISIBLE);
				ArrayAdapter<String> adapter_questions = new ArrayAdapter<String>(
						getApplicationContext(), R.layout.simple_spinner_item,
						questions);
				adapter_questions
						.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);
				spinner.setAdapter(adapter_questions);
			} else {
				if (serverOK == 1) {
					new AlertDialog.Builder(ForgotPasswordActivity.this)
							.setTitle("Message")
							.setMessage("Username is incorrect.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", null).show();
				} else {
					new AlertDialog.Builder(ForgotPasswordActivity.this)
							.setTitle("Message")
							.setMessage("Connection problem with the server.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", null).show();
				}

			}

		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		switch (v.getId()) {
		case R.id.btn_confirm_submit:
			if ((submit.getText().toString()).equals("Confirm")) {
				usernameStr = username.getText().toString().trim();
				if (Validation.hasText(username))
					new getQuestionInfo().execute();
			}
			if ((submit.getText().toString()).equals("Submit")) {
				String userAnswer = answer.getText().toString().trim();
				String userQuestinNumber = getQuestionNumber(selQuestion);

				if (userAnswer.equals(questionAnswer)
						&& userQuestinNumber.equals(questionNumber)) {
					new AlertDialog.Builder(ForgotPasswordActivity.this)
							.setTitle("New Password...")
							.setMessage(
									"The Android part of this service: In construction.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", new OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									finish();

								}
							}).show();

				} else {
					new AlertDialog.Builder(ForgotPasswordActivity.this)
							.setTitle("Message")
							.setMessage("Question or Answer are incorrect.")
							.setIcon(android.R.drawable.ic_dialog_info)
							.setNeutralButton("OK", null).show();
				}
			}
			break;

		default:
			break;
		}

	}

	private String getQuestionNumber(String selQuestion2) {

		for (int i = 0; i < questions.length; i++) {
			if (selQuestion.equals(questions[i])) {
				i++;
				return "" + i;
			}
		}
		return "" + 0;
	}

}
